const pizzaform = document.getElementById("pizzaform");

if (pizzaform) {
    pizzaform.addEventListener("submit", function (e) {
        e.preventDefault();

        const flavour = document.getElementById("flavour:").value;
        const sizePrice = document.getElementById("sizePrice:").value;

        const reader = new FileReader();

        reader.onload = function () {

            const newPizza = {
                flavour: flavour,
                sizePrice: sizePrice,


            };

            let pizza = JSON.parse(localStorage.getItem("pizza")) || [];
            pizza.push(newPizza);
            localStorage.setItem("pizza", JSON.stringify(pizza));

            alert("pizza added successfully!");
            pizzaform.reset();
        };
    });
}



const List = document.getElementById("List");
if (List) {
    renderpizza();
}

function renderpizza() {
    let pizza = JSON.parse(localStorage.getItem("pizza")) || [];
    List.innerHTML = "";

    if (pizza.length === 0) {
        List.innerHTML = "<p>No pizza available. Add some first!</p>";
        return;
    }

    cars.forEach((pizza, _index) => {
        const card = document.createElement("div");
        card.classList.add("pizza-card");

        card.innerHTML = `
      <h3>${pizza.pizzaform}</h3>
      
      <p><strong>flavour:</strong> ${pizza.flavour} </p>
      <p><strong>size/price:</strong> ${pizza.sizePrice} </p>`

        List.appendChild(card);
    });
}
